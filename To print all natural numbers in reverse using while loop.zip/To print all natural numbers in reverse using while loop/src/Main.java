import java.util.Scanner;

class main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number");
        int n= sc.nextInt();
        int i=n;
        while (i<=n){
            System.out.println(i);
            i--;

        }

    }
}