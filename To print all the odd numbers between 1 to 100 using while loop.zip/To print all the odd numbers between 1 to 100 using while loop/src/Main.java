import java.util.Scanner;

class main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int i=1;
        while (i<=100){
            if(i%2!=0){
                System.out.println(i);
                
            }
            i++;

        }

    }
}