import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        String s=sc.next();
        char a=s.charAt(0);
        int l=s.length();
        char b=s.charAt(l-1);
        String K=s.substring(1,l-1);
        s=b+K+a;
        System.out.println(s);
    }
}