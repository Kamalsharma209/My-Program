import java.util.Scanner;

class main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number");
        int n= sc.nextInt();
        int i=0;
        while (i<=9) {
            i++;
            System.out.println(n*i);
        }
    }
}