import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the first number");
        int num1 =sc.nextInt();
        switch (num1%2==0?1:0){
            case 0:
                System.out.println("ODD");
                break;
            case 1:
                System.out.println("EVEN");
        }
    }
}