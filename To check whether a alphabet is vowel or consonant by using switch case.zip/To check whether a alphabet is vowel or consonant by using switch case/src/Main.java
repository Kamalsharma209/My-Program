import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter the Alphabet(A to Z)");
        char alphabet =sc.next().charAt(0);
        switch (alphabet){
            case 'a':
            case 'e':
            case'i':
            case'o':
            case'u':
            case 'A':
            case'E':
            case'I':
            case'O':
            case'U':
                System.out.println("VOWEL");
            default:
                System.out.println("CONSONANT");


        }
    }
}