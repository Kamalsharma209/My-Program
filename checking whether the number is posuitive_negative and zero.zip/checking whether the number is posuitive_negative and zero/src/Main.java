import java.util.*;
class Identity {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter The  Number:");
        int num = input.nextInt();
        if (num>0)
            System.out.println("The is positive");
        else if(num<0)
            System.out.println("The Number negative");
        else
            System.out.println("Zero");
    }
}