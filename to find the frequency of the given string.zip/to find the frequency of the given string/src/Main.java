import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String S = sc.next();
        S = S.toLowerCase();
        int[] b = new int[26];
        for(int i=0; i<S.length(); i++){
            b[S.charAt(i)-'a']++;
        }
        for(int i=0; i<b.length; i++){
            if(b[i]>0)
            System.out.printf("%c= %d\n",i+97,b[i]);
        }

    }
}