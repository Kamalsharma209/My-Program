import java.util.*;
class MaximumNumber {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter The First Number:");
        int num1 = input.nextInt();
        System.out.print("Enter The Second Number:");
        int num2 = input.nextInt();
        System.out.print("Enter The Third Number:");
        int num3 =input.nextInt();
        if(num1>num2){
            if(num1>num3)
                System.out.println("First number is Maximum:");
            }
            else if (num3>num2)
                System.out.println("Third is maximum:");
        else
            System.out.println("Second Number is Maximum");
    }
}