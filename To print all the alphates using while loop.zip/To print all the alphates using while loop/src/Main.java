import java.util.Scanner;

class main{
    public static void main(String[]args){
        char temp= 'a';
        while(temp<='z'){
            System.out.println(temp);
            temp++;
        }
    }





}